<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <!-- Sidebar user panel (optional) -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="user/<?php echo $d['foto'];?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php echo $d['nama'];?></p>
                <!-- Status -->
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>

        <!-- search form (Optional) -->
        <form action="#" method="get" class="sidebar-form">
            <div class="input-group">
                <input type="text" name="q" class="form-control" placeholder="Search...">
                <span class="input-group-btn">
                    <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i></button>
                </span>
            </div>
        </form>
        <!-- /.search form -->

        <!-- Sidebar Menu -->
        <ul class="sidebar-menu">
            <li class="header">HEADER</li>
            <!-- Optionally, you can add icons to the links -->
            <?php
                $class1 = "";
                if(!isset($_GET['mod']) || $_GET['pg']=='home') {
                    $class1 = "class='active'";
                }
            ?>
            <li <?=$class1;?>>
                <a href="index.php"><i class="fa  fa-dashboard"></i> <span>Dashboard</span></a>
            </li>
            <?php
                $class2 = "";
                if (isset($_GET['pg']) && ($_GET['pg'] =='formulasi' || $_GET['pg']=='bujur_sangkar')) {
                    $class2 = "active";
                }
            ?>
            <li class="treeview <?=$class2;?>">
                <a href="#">
                    <i class="fa fa-credit-card"></i>
                    <span>Formulasi Pakan</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <?php
                    $class3 = "";
                    if (isset($_GET['pg']) && ($_GET['pg']=='formulasi')) {
                        $class3 = "class='active'";
                    }?>
                    <li <?=$class3;?>>
                        <a href="index.php?mod=formulasi&pg=formulasi">Trial And Error</a>
                    </li>

                    <?php
                    $class4 = "";
                    if (isset($_GET['pg']) && ($_GET['pg']=='bujur_sangkar')) {
                        $class4 = "class='active'";
                    }?>
                    <li <?=$class4;?>><a href="index.php?mod=formulasi&pg=bujur_sangkar">Bujur Sangkar</a></li>

                </ul><!-- /.sidebar-menu -->
            </li>

            <?php
            $class5 = "";
            if(isset($_GET['mod']) && ($_GET['mod'] == 'user')) {
                $class5 = "class='active'";
            }?>
            <li <?=$class5;?>>
                <a href="index.php?mod=user&pg=option_user"><i class="fa fa-users"></i> <span>User</span></a>
            </li>

            <?php
            $class6 = "";
            if(isset($_GET['mod']) && ($_GET['mod'] == 'pakan')) {
                $class6 = "class='active'";
            }?>
            <li <?=$class6;?>>
                <a href="index.php?mod=pakan&pg=option_pakan"><i class="fa fa-users"></i> <span>Pakan</span></a>
            </li>

            <?php
            $class7 = "";
            if(isset($_GET['mod']) && ($_GET['mod'] == 'laporan')) {
                $class7 = "class='active'";
            }?>
            <li <?=$class7;?> >
                <a href="index.php?mod=kriteria&pg=option_kriteria"><i class="fa  fa-industry"></i> <span>'Laporan'</span></a>
            </li>

            <?php
            $class8 = "";
            if (isset($_GET['mod']) && ($_GET['mod']=='forum')) {
                $class8 = "class='active'";
            }?>
            <li <?=$class8;?> >
                <a href="index.php?mod=kriteria&pg=option_kriteria"><i class="fa  fa-industry"></i> <span>Forum Diskusi</span></a>
            </li>

            <?php
                $class9 = "";
                if (isset($_GET['pg']) && ($_GET['pg']=='edit_user' || $_GET['pg']=='update_password' || $_GET['pg']=='set_home' || $_GET['pg']=='set_about' || $_GET['pg']=='set_contak' || $_GET['pg']=='set_costume')) {
                    $class9 = "active";
                }
            ?>
            <li class="treeview <?=$class9;?>">
                <a href="#"><i class="fa fa-wrench"></i> <span>Setting</span> <i class="fa fa-angle-left pull-right"></i></a>
                <ul class="treeview-menu">
                    <?php
                    $class10 = "";
                    if (isset($_GET['pg']) && ($_GET['pg'] == 'edit_user')) {
                        $class10 = "class='active'";
                    }?>
                    <li <?=$class10;?>>
                        <a href="index.php?mod=user&pg=edit_user&id=<?php echo $d['id_user'];?>">Edit Profil</a>
                    </li>

                    <?php
                    $class11 = "";
                    if (isset($_GET['pg']) && ($_GET['pg']=='update_password')) {
                        $class11 = "class='active'";
                    }?>
                    <li <?=$class11;?>>
                        <a href="index.php?mod=user&pg=update_password&id=<?php echo $d['id_user'];?>">Ganti Password</a>
                    </li>

                    <?php
                    $class12 = "";
                    if (isset($_GET['pg']) && ($_GET['pg']=='set_home')) {
                        $class12 = "class='active'";
                    }?>
                    <li <?=$class12;?>>
                        <a href="index.php?mod=pages&pg=set_home">Home</a>
                    </li>

                    <?php
                    $class13 = "";
                    if (isset($_GET['pg']) && ($_GET['pg']=='set_about')) {
                        $class13 = "class='active'";
                    }?>
                    <li <?=$class13;?>>
                        <a href="index.php?mod=pages&pg=set_about">About</a>
                    </li>

                    <?php
                    $class14 = "";
                    if (isset($_GET['pg']) && ($_GET['pg']=='set_contak')) {
                        $class14 = "class='active'";
                    }?>
                    <li <?=$class14;?>>
                        <a href="index.php?mod=pages&pg=set_contak">Contak</a>
                    </li>

                    <?php
                    $class15 = "";
                    if (isset($_GET['pg']) && ($_GET['pg']=='set_costume')) {
                        $class15 = "class='active'";
                    }?>
                    <li <?=$class15;?>>
                        <a href="index.php?mod=pages&pg=set_costume">Costome</a>
                    </li>

                </ul>
            </li>
        </ul><!-- /.sidebar-menu -->
    </section>
</aside>