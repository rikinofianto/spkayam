<section class="content-header">
  <h1>
    Formulasi
    <small>Resum ( Trial and Error Method )</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">Input Formulasi Pakan</li>
  </ol>
</section>
        <!-- Main content -->
<section class="content">
          <div class="row">
            <div class="col-md-12">
              <div class="box box-info">
                <div class="box-header">
                  <h3 class="box-title">Input Formulasi Pakan<small></small></h3>
                  <!-- tools box -->
                  <div class="pull-right box-tools">
                    <button class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
                  </div><!-- /. tools -->
                </div><!-- /.box-header -->
                <div class="box-body pad">
<form action="index.php?mod=formulasi&pg=formulasi" method="post">
      <table width="100%" border="0" cellpadding="5" cellspacing="5">
        <tr>
          <th colspan="2">Input Protein</th>
          <th colspan="2">Input Pakan + Harga/Kg</th>
        </tr>
        <tr>
          <td width="18%">Kosentar</td>
          <td width="26%">
              <div class="input-group">
                <input type="text" size="5" name="k1" value="<?php if(!isset($_POST['k1'])){
      echo"0";
      }else{echo $_POST['k1'];} ?>" class="form-control">
                <span class="input-group-addon">%</span> </div></td>
          <td width="23%">
              <div class="input-group">
                <input type="text" size="5" name="k2" value="<?php if(!isset($_POST['k2'])){
      echo"0";
      }else{echo $_POST['k2'];} ?>" class="form-control">
                <span class="input-group-addon">%</span> </div></td>
          <td width="33%">
            <div class="input-group">
            <span class="input-group-addon">Rp</span>
                    <input type="text" size="12" name="hk" value="<?php if(!isset($_POST['hk'])){
      echo"0";
      }else{echo $_POST['hk'];} ?>" class="form-control">
                    <span class="input-group-addon">/Kg</span>
                  </div>
            </td>
        </tr>
        <tr>
          <td>Pakan Jadi</td>
          <td>
            <div class="input-group">
                    <input type="text" size="5" name="j1" value="<?php if(!isset($_POST['j1'])){
      echo"0";
      }else{echo $_POST['j1'];} ?>" class="form-control">
                    <span class="input-group-addon">%</span>
                  </div></td>
          <td>
              <div class="input-group">
                <input type="text" size="5" name="j2" value="<?php if(!isset($_POST['j2'])){
      echo"0";
      }else{echo $_POST['j2'];} ?>" class="form-control">
                <span class="input-group-addon">%</span> </div></td>
          <td>
            <div class="input-group"> <span class="input-group-addon">Rp</span>
              <input type="text"  size="12" name="hp" value="<?php if(!isset($_POST['hp'])){
      echo"0";
      }else{echo $_POST['hp'];} ?>" class="form-control">
              <span class="input-group-addon">/Kg</span> </div></td>
        </tr>
        <tr>
          <td>Dedak</td>
          <td>
              <div class="input-group">
                <input type="text" size="5" name="d1" value="<?php if(!isset($_POST['d1'])){
      echo"0";
      }else{echo $_POST['d1'];} ?>" class="form-control">
                <span class="input-group-addon">%</span> </div></td>
          <td>
              <div class="input-group">
                <input type="text" size="5" name="d2" value="<?php if(!isset($_POST['d2'])){
      echo"0";
      }else{echo $_POST['d2'];} ?>" class="form-control">
                <span class="input-group-addon">%</span> </div></td>
          <td>
            <div class="input-group"> <span class="input-group-addon">Rp</span>
              <input type="text" size="12" name="hd" value="<?php if(!isset($_POST['hd'])){
      echo"0";
      }else{echo $_POST['hd'];} ?>" class="form-control">
              <span class="input-group-addon">/Kg</span> </div></td>
        </tr>
        <tr>
          <td colspan="2">Jumlah Pakan Yang Akan Di Buat</td>
          <td><div class="input-group">
                    <input type="text" size="12" name="pk" value="<?php if(!isset($_POST['pk'])){
      echo"0";
      }else{echo $_POST['pk'];} ?>" class="form-control">
                    <span class="input-group-addon">.Kg</span>
                  </div></td>
          <td></td>
        </tr>
        <tr>
          <td> <div class="box-footer">
                    <button type="submit"  name="hitung" value="Hitung" class="btn btn-primary">Hitung</button>
                </div>
            </td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td colspan="4"><hr size="3" color="#666666"/>
            <hr size="1" color="#666666" />
      <?php
if(isset($_POST['hitung'])){
$k1=$_POST['k1'];
$k2=$_POST['k2'];
$j1=$_POST['j1'];
$j2=$_POST['j2'];
$d1=$_POST['d1'];
$d2=$_POST['d2'];
$pk=$_POST['pk'];
$hk=$_POST['hk'];
$hp=$_POST['hp'];
$hd=$_POST['hd'];
$pp=$k2+$j2+$d2;
$k2k=$k2/$pp*100;
$j2j=$j2/$pp*100;
$d2d=$d2/$pp*100;
$tpa=$k2k+$j2j+$d2d;
$k1k=$k2k*$k1/100;
$j1j=$j2j*$j1/100;
$d1d=$d2d*$d1/100;
$tp=$k1k+$j1j+$d1d;
$kpk=$k2k*$pk/100;
$jpk=$j2j*$pk/100;
$dpk=$d2d*$pk/100;
$tc=$kpk+$jpk+$dpk;
$thk=$kpk*$hk;
$thp=$jpk*$hp;
$thd=$dpk*$hd;
$jumharga=$thk+$thp+$thd;
?>
<div class="box">
                <div class="box-header">
                  <h3 class="box-title">Hasil Formulasi Pakan</h3>
                </div><!-- /.box-header -->
                <div class="box-body no-padding">
                  <table class="table table-striped">
                    <tr>
                      <th style="width: 10px">#</th>
                      <th>Pakan</th>
                      <th>Campuran Pakan</th>
                      <th>Sumbangan Protein (%)</th>
                      <th>Total Campuran (Kg)</th>
                      <th>Total Cost (Kg/Rp)</th>
                    </tr>      
                    <tr>
                      <td>1.</td>
                      <td>Kosentrat</td>
                      <td> <span class="badge bg-red"><?php echo "".round($k2k,2)."";?>%</span></td>
                      <td> <span class="badge bg-red"><?php echo "".round($k1k,2)."";?>%</span></td>
                      <td> <span class="badge bg-red"><?php echo "".round($kpk).""; ?> Kg</span></td>
                      <td><strong><?php echo "Rp.".number_format($thk).""; ?></strong></td>
                    </tr>  
                    <tr>
                      <td>2.</td>
                      <td>Pakan Jadi</td>
                      <td><span class="badge bg-yellow"><?php echo "".round($j2j,2)."";?>%</span></td>
                      <td><span class="badge bg-yellow"><?php echo "".round($j1j,2)."";?>%</span></td>
                      <td><span class="badge bg-yellow"><?php echo "".round($jpk).""; ?> Kg</span></td>
                      <td><strong><?php echo "Rp.".number_format($thp).""; ?></strong></td>
                    </tr>
                    <tr>
                      <td>3.</td>
                      <td>Dedak</td>
                      <td> <span class="badge bg-light-blue"><?php echo "".round($d2d,2)."";?>%</span> </td>
                      <td><span class="badge bg-light-blue"><?php echo "".round($d1d,2)."";?>%</span></td>
                      <td><span class="badge bg-light-blue"><?php echo "".round($dpk)."";?> Kg</span></td>
                      <td><strong><?php echo "Rp.".number_format($thd).""; ?></strong></td>
                    </tr>
                    <tr>
                      <td>#</td>
                      <td><strong>Total</strong></td>
                      <td><strong><?php echo "".round($tpa,2)."";?>%</strong> </td>
                      <td><strong><?php echo "".round($tp,2)."";?>%</strong></td>
                      <td><strong><?php echo "".round($tc,2)."";?> Kg</strong></td>
                      <td><strong><?php echo "Rp.".number_format($jumharga).""; ?></strong></td>
                    </tr>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->



<?php }
else{ echo "<table cellpadding='10' cellspacing='10' borde='0' width='60%'><tr><td><div class='alert alert-danger alert-dismissable'>
                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                    <h4><i class='icon fa fa-ban'></i> Warning!!!</h4>
                  Anda Belum Memasukkan Input Pakan !
                  </div></td></tr></table>";}
?>
</td></tr></table>
</form></div></div></div></div></section>