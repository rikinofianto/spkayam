<?php include"koneksi.php";?>
<section class="content-header">
    <h1>
        Formulasi
        <small>Resum ( Bujur Sangkar Person )</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Input Formulasi Pakan</li>
    </ol>
</section>
<!-- Main content -->

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-info">
                <div class="box-header">
                    <h3 class="box-title">Input Formulasi Pakan<small></small></h3>
                    <!-- tools box -->
                    <div class="pull-right box-tools">
                        <button class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                        <button class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
                    </div><!-- /. tools -->
                </div><!-- /.box-header -->
                <div class="box-body pad">
                    <form action="index.php?mod=formulasi&pg=bujur_sangkar" method="post">
                        <?php
                        $sql = "SELECT id_umur, umur FROM umur";
                        $query = mysql_query($sql);?>
                        <table width="100%" border="0" cellpadding="5" cellspacing="5">
                            <tr>
                                <td colspan="2"><strong>Total Protein</strong></td>
                                <td colspan="3" width="71%" colspan="2" style="padding-bottom: 5px;">
                                    <div class="input-group" style="width: 36%">
                                        <?php if(!isset($_POST['tot_protein'])){
                                            $val = '0';
                                        } else {
                                            $val = $_POST['tot_protein'];
                                        }
                                        ?>
                                        <input type="text" size="3" name="tot_protein" value="<?=$val;?>" class="form-control">
                                        <span class="input-group-addon">%</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2"><strong>Jumlah Pakan Yang di Campur</strong></td>
                                <td colspan="3" style="padding-bottom: 5px;">
                                    <div class="input-group" style="width: 36%">
                                        <?php if(!isset($_POST['tot_campuran'])){
                                            $val2 = "0";
                                        } else {
                                            $val2 = $_POST['tot_campuran'];
                                        } ?>
                                        <input type="text" size="10" name="tot_campuran" value="<?=$val2;?>" class="form-control">
                                        <span class="input-group-addon">Kg</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2"><strong>Umur Ayam</strong></td>
                                <td colspan="3" style="padding-bottom: 5px;">
                                    <select class="form-control" name="id_umur" style="width:36%" id="umur_ayam">
                                        <option>-Pilih Umur ayam-</option>
                                        <?php if (mysql_num_rows($query)) :
                                            while ($umr = mysql_fetch_assoc($query)) :?>
                                                <?php if (isset($_POST['id_umur']) && $_POST['id_umur'] == $umr['id_umur']) :?>
                                                    <option value="<?=$umr['id_umur'];?>" selected="selected"><?=$umr['umur'];?></option>
                                                <?php else :?>
                                                    <option value="<?=$umr['id_umur'];?>"><?=$umr['umur'];?></option>
                                                <?php endif;?>
                                            <?php endwhile;
                                        endif;?>
                                    </select>
                                </td>
                            </tr>
                            <tr id="ajax-content-0"></tr>
                            <tr id="ajax-content-1"></tr>
                            <tr id="ajax-content-2"></tr>
                            <tr>
                                <td colspan="4">
                                    <div class="box-footer">
                                        <button type="submit"  name="hitung" value="Hitung" class="btn btn-primary">Formulasi</button>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php if (isset($_POST['hitung']) && isset($_POST['id_umur']) && isset($_POST['tot_protein']) && isset($_POST['tot_campuran'])) :?>
<?php
//query umur
$sql_umur = "SELECT * FROM umur WHERE id_umur = '$_POST[id_umur]'";
$query_umur = mysql_query($sql_umur);
$umur = mysql_fetch_assoc($query_umur);

//query pakan utama
$sql_pakan_u = "SELECT * FROM makanan WHERE id_pakan = '$_POST[pakan_utama]'";
$query_pakan_u = mysql_query($sql_pakan_u);
$pakan_u = mysql_fetch_assoc($query_pakan_u);

//harga pakan utama
$sql_harga_u = "SELECT * FROM harga_pakan WHERE id_pakan = '$_POST[pakan_utama]' AND id_user ='$d[id_user]'";
$query_harga_u = mysql_query($sql_harga_u);
$harga_u = mysql_fetch_assoc($query_harga_u);

//protein kasar pakan utama ($pku) (%)
$pku = $pakan_u['protein'];
//menghitung bagian protein dari total protein yang ingin didapat (%)
$bpku = intval($pku) - intval($_POST['tot_protein']);

//query pakan campuran 1
$sql_pakan_1 = "SELECT * FROM makanan WHERE id_pakan = '$_POST[pakan_1]'";
$query_pakan_1 = mysql_query($sql_pakan_1);
$pakan_1 = mysql_fetch_assoc($query_pakan_1);

//harga pakan campuran 1
$sql_harga_1 = "SELECT * FROM harga_pakan WHERE id_pakan = '$_POST[pakan_1]' AND id_user ='$d[id_user]'";
$query_harga_1 = mysql_query($sql_harga_1);
$harga_1 = mysql_fetch_assoc($query_harga_1);

//protein kasar pakan campuran 1 ($pk1) (%)
$pk1 = $pakan_1['protein'];
//menghitung bagian protein dari total protein yang ingin didapat (%)
$bpk1 = intval($_POST['tot_protein']) - intval($pk1);

if (!empty($_POST['pakan_2'])) {
    //query pakan campuran 2
    $sql_pakan_2 = "SELECT * FROM makanan WHERE id_pakan = '$_POST[pakan_2]'";
    $query_pakan_2 = mysql_query($sql_pakan_2);
    $pakan_2 = mysql_fetch_assoc($query_pakan_2);

    //protein kasar pakan campuran 2 ($pk2) (%)
    $pk2 = $pakan_2['protein'];

    //menghitung perbandingan protein pakan campuran 1 dan pakan campuran 2 yaitu 1:2
    $hitung1 = (1 * intval($pk1)) + (2 * intval($pk2));
    $ppk = $hitung1/3;
    $pk1 = $ppk;
    //menghitung bagian protein dari total protein yang ingin didapat (%)
    $bpk1 = intval($_POST['tot_protein']) - intval($ppk);

    //harga pakan campuran 1
    $sql_harga_2 = "SELECT * FROM harga_pakan WHERE id_pakan = '$_POST[pakan_1]' AND id_user ='$d[id_user]'";
    $query_harga_2 = mysql_query($sql_harga_2);
    $harga_2 = mysql_fetch_assoc($query_harga_2);

}

$total_campuran = 0;
//penghitung prosentase penggunaan pakan
$total_bagian = $bpk1 + $bpku;
$total_bagian_u = ($bpk1/$total_bagian) * 100;
$total_bagian_1 = ($bpku/$total_bagian) * 100;
$total_campuran += $total_bagian_u;

$total_sumb_protein = 0;
//sumbangan protein pakan
$sumb_protein_u = ($total_bagian_u/100) * intval($pku);
$sumb_protein_1 = ($total_bagian_1/100) * intval($pk1);
$total_sumb_protein += $sumb_protein_u;

$total_kg_all = 0;
//total banyaknya campuran (Kg)
$total_kg_u = ($total_bagian_u/100) * intval($_POST['tot_campuran']);
$total_kg_1 = ($total_bagian_1/100) * intval($_POST['tot_campuran']);
$total_kg_all += $total_kg_u;

$total_rp_all = 0;
//menghitung harga
$total_rp_u = round($total_kg_u, 2) * intval($harga_u['harga']);
$total_rp_1 = round($total_kg_1, 2) * intval($harga_1['harga']);
$total_rp_all += $total_rp_u;

if (!empty($_POST['pakan_2'])) {
    $total_bagian_1_2 = $total_bagian_1;
    //penghitung prosentase penggunaan pakan
    $total_bagian_1 = (1/3) * $total_bagian_1_2;
    $total_bagian_2 = (2/3) * $total_bagian_1_2;
    $total_campuran += $total_bagian_1;
    $total_campuran += $total_bagian_2;

    //sumbangan protein
    $sumb_protein_1 = (round($total_bagian_1, 1)/100) * intval($pakan_1['protein']);
    $sumb_protein_2 = ($total_bagian_2/100) * intval($pk2);
    $total_sumb_protein += $sumb_protein_1;
    $total_sumb_protein += $sumb_protein_2;

    //total banyaknya campuran (Kg)
    $total_kg_1 = ($total_bagian_1/100) * intval($_POST['tot_campuran']);
    $total_kg_2 = ($total_bagian_2/100) * intval($_POST['tot_campuran']);
    $total_kg_all += $total_kg_1;
    $total_kg_all += $total_kg_2;

    //total harga pakan
    $total_rp_1 = round($total_kg_1, 2) * intval($harga_1['harga']);
    $total_rp_2 = round($total_kg_2, 2) * intval($harga_2['harga']);
    $total_rp_all += $total_rp_1;
    $total_rp_all += $total_rp_2;
} else {
    $total_campuran += $total_bagian_1; //total bagian protein (%)
    $total_sumb_protein += $sumb_protein_1; //total sumbangan protein (%)
    $total_kg_all += $total_kg_1; //total banyaknya campuran (Kg)
    $total_rp_all += $total_rp_1; //total harga (Rp)
}
?>
<div class="content" style="min-height: 0">
<?php if ($_POST['tot_protein'] < 10) :?>
    <div class='alert alert-warning alert-dismissable'>
        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
        <h4><i class='icon fa fa-ban'></i> Peringatan!!!</h4>
         Total Protein yang Anda masukkan terlalu Sedikit
    </div>
<?php elseif ($_POST['tot_protein'] > 40) :?>
    <div class='alert alert-warning alert-dismissable'>
        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
        <h4><i class='icon fa fa-ban'></i> Peringatan!!!</h4>
         Total Protein yang Anda masukkan terlalu Bayak
    </div>
<?php endif;?>
</div>
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-success">
                <div class="box-header">
                    <h3 class="box-title">Hasil Formulasi Pakan <small>Umur (<?=$umur['umur'];?>)</small></h3>
                    <!-- tools box -->
                    <div class="pull-right box-tools">
                        <button class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                        <button class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
                    </div><!-- /. tools -->
                </div><!-- /.box-header -->
                <div class="box-body pad">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <th style="width: 10px">#</th>
                                <th>Pakan</th>
                                <th>Campuran Pakan (%)</th>
                                <th>Sumbangan Protein (%)</th>
                                <th>Total Campuran (Kg)</th>
                                <th>Total Cost (Kg/Rp)</th>
                            </tr>
                            <tr>
                                <td>1.</td>
                                <td><?=$pakan_u['nama_pakan'];?></td>
                                <td>
                                    <span class="badge bg-yellow"><?=round($total_bagian_u, 1);?>%</span>
                                </td>
                                <td>
                                    <span class="badge bg-yellow"><?=round($sumb_protein_u, 1);?>%</span>
                                </td>
                                <td>
                                    <span class="badge bg-yellow"><?=round($total_kg_u, 2);?> Kg</span>
                                </td>
                                <td>
                                    Rp.<?=number_format($total_rp_u,2,',','.');?>
                                </td>
                            </tr>
                            <tr>
                                <td>2.</td>
                                <td><?=$pakan_1['nama_pakan'];?></td>
                                <td>
                                    <span class="badge bg-red"><?=round($total_bagian_1, 1);?>%</span>
                                </td>
                                <td>
                                    <span class="badge bg-red"><?=round($sumb_protein_1, 1);?>%</span>
                                </td>
                                <td>
                                    <span class="badge bg-red"><?=round($total_kg_1, 2);?> Kg</span>
                                </td>
                                <td>
                                    Rp.<?=number_format($total_rp_1,2,',','.');?>
                                </td>
                            </tr>
                            <?php if (!empty($_POST['pakan_2'])) :?>
                            <tr>
                                <td>3.</td>
                                <td><?=$pakan_2['nama_pakan'];?></td>
                                <td>
                                    <span class="badge bg-light-blue"><?=round($total_bagian_2, 1);?>%</span>
                                </td>
                                <td>
                                    <span class="badge bg-light-blue"><?=round($sumb_protein_2, 1);?>%</span>
                                </td>
                                <td>
                                    <span class="badge bg-light-blue"><?=round($total_kg_2, 2);?> Kg</span>
                                </td>
                                <td>
                                    Rp.<?=number_format($total_rp_2,2,',','.');?>
                                </td>
                            </tr>
                            <?php endif;?>
                                <th>#</th>
                                <th>Total</th>
                                <th>
                                    <?=round($total_campuran, 2);?>%
                                </th>
                                <th>
                                    <?=round($total_sumb_protein, 2);?>%
                                </th>
                                <th>
                                    <?=round($total_kg_all, 2);?> Kg
                                </th>
                                <th>
                                    Rp.<?=number_format($total_rp_all,2,',','.');?>
                                </th>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<?php else :?>

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-danger">
                <div class="box-header">
                    <h3 class="box-title">Hasil Formulasi Pakan <small></small></h3>
                    <!-- tools box -->
                    <div class="pull-right box-tools">
                        <button class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                        <button class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
                    </div><!-- /. tools -->
                </div><!-- /.box-header -->
                <div class="box-body pad">
                    <h4>Silahkan Isi semua inputan diatas untuk melihat hasil.</h4>
                </div>
            </div>
        </div>
    </div>
</section>

<?php endif;?>
<script>
$(document).ready(function(){
    //untuk pilih pakan utama
    $("#umur_ayam").change(function(){
        var umur = $(this).val();
        $.ajax({
            type: 'POST',
            data : {id_umur : umur},
            url: "ajax-pakan.php",
            success: function(result){
            $("#ajax-content-0").html(result);
        }});
    });

});
</script>