<?php
include ('../koneksi.php');
$id = $_POST['id'];
$nama = $_POST['nama'];
$id_user = $_POST['user'];
$harga = $_POST['harga'];

$sql = "update harga_pakan set id_pakan='$nama',
		id_user='$id_user',
		harga='$harga'		
 		where id_harga_p='$id'";          
					$res=mysql_query($sql) or die (mysql_error());   
echo "<script>alert ('data telah di Update');document.location='../index.php?mod=pakan&pg=option_pakan' </script> ";
?>