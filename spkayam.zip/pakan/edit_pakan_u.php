<?php
    include"koneksi.php";
    $id = $_GET['id'];
    $sql_ep="SELECT * FROM umur WHERE id_umur ='$id'";
    $qry_ep = mysql_query($sql_ep) or die ("gagal menampilkan".mysql_error());
    $hsl =mysql_fetch_assoc($qry_ep);
?>
<section class="content-header">
    <h1>
        Umur
        <small>Edit</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="index.php?mod=pakan&pg=option_pakan">Pakan</a></li>
        <li class="active">Edit Umur</li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-info">
                <div class="box-header">
                    <h3 class="box-title">Edit Umur<small></small></h3>
                    <!-- tools box -->
                    <div class="pull-right box-tools">
                        <button class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                        <button class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
                    </div><!-- /. tools -->
                </div><!-- /.box-header -->
                <div class="box-body pad">
                    <form id="form1" name="form1" method="post" action="pakan/simedit_u.php">
                        <input type="hidden" value="<?php echo "$id"; ?>" name="id" />
                        <table width="575" border="0" cellpadding="5" cellspacing="0"> 
                            <tr>
                                <td>Batas Umur Awal</td>
                                <td style="padding-bottom: 5px;">
                                    <div class="input-group">
                                        <input type="text" value="<?=$hsl['batas_awal']; ?>" name="awal" required="required" class="form-control">
                                        <span class="input-group-addon">Minggu</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>Batas Umur Akhir</td>
                                <td>
                                    <div class="input-group">
                                        <input type="text" value="<?=$hsl['batas_akhir'];?>" name="akhir" required="required" class="form-control">
                                        <span class="input-group-addon">Minggu</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <input type="submit" class="btn btn-primary" name="Submit" value="Simpan" />
                                    <input type="reset" class="btn btn-primary" name="Submit2" value="Reset" />
                                </td>
                            </tr>
                        </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
