<?php
include'../koneksi.php';

$id=$_GET['id'];

if (empty ($id)) {
	echo "Data yang dihapus belum dipilih";
}
else {
	$sql_hapus="DELETE FROM harga_pakan WHERE id_harga_p='$id'";
	mysql_query($sql_hapus)
		or die ("Gagal perintah hapus".mysql_error());	
	
echo "<script>alert ('data telah di Hapus ');document.location='../index.php?mod=pakan&pg=option_pakan' </script> ";	exit;
}
?>