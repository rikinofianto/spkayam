<?php
include ('../koneksi.php');
$nama = $_POST['nama'];
$harga = $_POST['harga'];
$id_user = $_POST['id_user'];

$q = mysql_query("select * from harga_pakan where id_pakan='$nama' and id_user='$id_user'");

if (mysql_num_rows($q) == 1) {
	echo "<script>alert ('Harga Pakan yang anda Upload Sudah ada, cari yang lain/edit Harga ');document.location='../index.php?mod=pakan&pg=option_pakan' </script> ";
} else {

$sql="INSERT INTO harga_pakan (id_pakan, harga, id_user) VALUES ('$nama','$harga','$id_user')";  
					$res=mysql_query($sql) or die (mysql_error());   
echo "<script>alert ('data telah di Upload ');document.location='../index.php?mod=pakan&pg=option_pakan' </script> ";
}
?>