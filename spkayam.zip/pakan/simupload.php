<?php
include ('../koneksi.php');
$nama = $_POST['nama'];
$protein = $_POST['protein'];
$variabel = $_POST['variabel'];
$id_umur = $_POST['id_umur'];

// $sql="INSERT INTO pakan (nama_pakan, protein, variabel) VALUES ('$nama','$protein','$variabel')";  
//                     $res=mysql_query($sql) or die (mysql_error());
$sql = "INSERT INTO makanan (id_umur, nama_pakan, protein, variabel) VALUES ('$id_umur', '$nama','$protein','$variabel')";
$res = mysql_query($sql) or die (mysql_error());
echo "<script>alert ('data telah di Upload ');document.location='../index.php?mod=pakan&pg=option_pakan' </script> ";

?>