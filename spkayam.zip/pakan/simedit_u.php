<?php
include ('../koneksi.php');
if (!empty($_POST)) {
    $id = $_POST['id'];
    $awal = $_POST['awal'];
    $akhir = $_POST['akhir'];
    $umur = $awal.' - '.$akhir.' Minggu';
    $sql = "update umur set batas_awal='$awal',
            batas_akhir='$akhir',
            umur='$umur'
            where id_umur='$id'";
    $res=mysql_query($sql) or die (mysql_error());
    if ($res) {
        echo "<script>alert ('data telah di Update');document.location='../index.php?mod=pakan&pg=option_pakan' </script> ";
    }
}

?>