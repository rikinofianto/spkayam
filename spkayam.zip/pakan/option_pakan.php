
<section class="content-header">
    <h1>Daftar <small>Pakan dan Harga</small></h1>
    <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Pakan</li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3>Daftar Pakan</h3>
                    <table width="200" border="0">
                        <tr>
                            <td>
                                <?php
                                if (isset($d['status']) && $d['status'] == 'admin') {?>
                                    <a href="index.php?mod=pakan&pg=upload_pakan" class="btn btn-block btn-social btn-bitbucket">
                                        <i class="fa fa-plus"></i> Tambah Pakan
                                    </a>
                                <?php } else {
                                    echo "";
                                } ?>
                            </td>
                        </tr>
                    </table>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th ><strong>Nama Pakan</strong></th>
                                <th ><strong>Variabel</strong></th>
                                <th><strong>Protein</strong></th>
                                <?php
                                    if (isset($d['status']) &&$d['status']=='admin') {?>
                                        <th ><strong>Option</strong></th>
                                    <?php } else {
                                        echo "";
                                    }?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql_p = "SELECT * FROM makanan order by id_pakan ASC";
                            $qry_p = mysql_query($sql_p);
                            if (mysql_num_rows($qry_p)) :
                                $no = 1;
                                while ($dt = mysql_fetch_assoc($qry_p)) :?>
                                    <tr>
                                        <td><?=$no;?></td>
                                        <td><?php echo $dt['nama_pakan']; ?></td>
                                        <td><?php echo $dt['variabel']; ?></td>
                                        <td class="td"><?php echo $dt['protein']; ?> % </td>
                                        <?php if (isset($d['status']) && $d['status'] == 'admin') :?>
                                            <td>
                                                <div class="text-center">
                                                    <a href="index.php?mod=pakan&pg=edit_pakan&id=<?php echo $dt['id_pakan']; ?>" class="btn btn-social-icon btn-dropbox"><i class="fa fa-pencil-square-o"></i></a>
                                                    <a href="pakan/hapus_pakan.php?id=<?php echo $dt['id_pakan']; ?>" class="btn btn-social-icon btn-google"><i class="fa fa-trash-o" onclick="return confirm('Apa anda yakin ingin menghapus data ini')"></i></a>
                                                </div>
                                            </td>
                                        <?php endif;?>
                                    </tr>
                                    <?php $no++;?>
                                <?php endwhile;?>
                            <?php endif;?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3>Daftar Harga</h3>
                    <table width="200" border="0">
                        <tr>
                            <td>
                                <a href="index.php?mod=pakan&pg=upload_harga" class="btn btn-block btn-social btn-bitbucket">
                                    <i class="fa fa-plus"></i> Tambah Harga Pakan
                                </a>
                            </td>
                        </tr>
                    </table>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th ><strong>Nama Pakan</strong></th>
                                <th ><strong>Harga</strong></th>

                                <th ><strong>Option</strong></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no=1;
                            $sql_h = "SELECT h.*, p.* FROM harga_pakan h, makanan p WHERE h.id_pakan=p.id_pakan AND h.id_user='$d[id_user]' ORDER BY p.id_pakan ASC";
                            $qry_h = mysql_query($sql_h);
                            if (mysql_num_rows($qry_h)) :
                                while ($datah = mysql_fetch_assoc($qry_h)) :?>
                                    <tr>
                                        <td><?php echo $no; ?></td>
                                        <td><?php echo $datah['nama_pakan']; ?></td>
                                        <td>Rp. <?php echo number_format($datah['harga']); ?></td>
                                        <td>
                                            <div class="text-center">
                                                <a href="index.php?mod=pakan&pg=edit_pakan_h&id=<?php echo $datah['id_harga_p']; ?>" class="btn btn-social-icon btn-dropbox">
                                                    <i class="fa fa-pencil-square-o"></i>
                                                </a>
                                                <a href="pakan/hapus_pakan_h.php?id=<?php echo $datah['id_harga_p']; ?>" class="btn btn-social-icon btn-google">
                                                    <i class="fa fa-trash-o" onclick="return confirm('Apa anda yakin ingin menghapus data ini');"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php $no++;?>
                                <?php endwhile;
                            endif;
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3>Daftar Kategori Umur</h3>
                    <table width="200" border="0">
                        <tr>
                            <td>
                                <a href="index.php?mod=pakan&pg=upload_umur" class="btn btn-block btn-social btn-bitbucket">
                                    <i class="fa fa-plus"></i> Tambah Kategori Umur
                                </a>
                            </td>
                        </tr>
                    </table>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th style="width: 1%;">No</th>
                                <th ><strong>Range Umur (Minggu)</strong></th>
                                <th ><strong>Option</strong></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no=1;
                            $sql_u = "SELECT * FROM umur ORDER BY batas_awal ASC";
                            $qry_u = mysql_query($sql_u);
                            if (mysql_num_rows($qry_u)) :
                                while ($datau = mysql_fetch_assoc($qry_u)) :?>
                                    <tr>
                                        <td><?php echo $no; ?></td>
                                        <td><?php echo $datau['umur']; ?></td>
                                        <td>
                                            <div class="text-center">
                                                <a href="index.php?mod=pakan&pg=edit_pakan_u&id=<?php echo $datau['id_umur']; ?>" class="btn btn-social-icon btn-dropbox">
                                                    <i class="fa fa-pencil-square-o"></i>
                                                </a>
                                                <a href="pakan/hapus_pakan_u.php?id=<?php echo $datau['id_umur']; ?>" class="btn btn-social-icon btn-google">
                                                    <i class="fa fa-trash-o" onclick="return confirm('Apa anda yakin ingin menghapus data ini');"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php $no++;?>
                                <?php endwhile;
                            endif;
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>