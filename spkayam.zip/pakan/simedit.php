<?php
include ('../koneksi.php');
$id = $_POST['id'];
$nama = $_POST['nama'];
$protein = $_POST['protein'];
$variabel = $_POST['variabel'];

$sql = "update makanan set nama_pakan='$nama',
        protein='$protein',
        variabel='$variabel'
        where id_pakan='$id'";
                    $res=mysql_query($sql) or die (mysql_error());
echo "<script>alert ('data telah di Update');document.location='../index.php?mod=pakan&pg=option_pakan' </script> ";
?>