<?php
include ('../koneksi.php');
if (isset($_POST)) {
    $awal = $_POST['awal'];
    $akhir = $_POST['akhir'];
    $umur = $awal.' - '.$akhir.' Minggu';

    $q = mysql_query("SELECT * FROM umur WHERE batas_awal = '$awal' || batas_akhir='$akhir'");

    if (mysql_num_rows($q) > 0) {
        echo "<script>alert (' Kategori Umur sudah ada dalam database.');document.location='../index.php?mod=pakan&pg=option_pakan' </script> ";
    } else {

        $sql="INSERT INTO umur (id_umur, batas_awal, batas_akhir, umur) VALUES ('', '$awal','$akhir','$umur')";
        $res = mysql_query($sql) or die (mysql_error());
        if ($res) {
            echo "<script>alert ('data telah di Upload ');document.location='../index.php?mod=pakan&pg=option_pakan' </script> ";
        }
    }
}
?>