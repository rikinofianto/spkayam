 <section class="content-header">
    <h1>
        Harga
        <small>Upload</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="index.php?mod=pakan&pg=option_pakan">Pakan</a></li>
        <li class="active">Upload Harga Pakan</li>
    </ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-info">
                <div class="box-header">
                    <h3 class="box-title">Upload Harga Pakan<small></small></h3>
                    <!-- tools box -->
                    <div class="pull-right box-tools">
                        <button class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                        <button class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
                    </div><!-- /. tools -->
                </div><!-- /.box-header -->
            <div class="box-body pad">
                <form id="form1" name="form1" method="post" action="pakan/simupload_h.php">
                    <table width="575" border="0" cellpadding="5" cellspacing="0">
                        <tr>
                            <td>
                                <div class="form-group">
                                    <label>Pilih Nama Pakan</label>
                                    <select name="nama" class="form-control">
                                        <?php
                                        $sql_h = "SELECT * FROM makanan order by id_pakan desc";
                                        $qry_h = mysql_query($sql_h) 
                                        or die('Gagal query'.mysql_error());
                                        while($data_h = mysql_fetch_array($qry_h)) {?>
                                            <option value="<?php echo $data_h['id_pakan']; ?>"><?php echo $data_h['nama_pakan'].' ('.$data_h['variabel'].')'; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Harga Pakan<br />
                                <div class="input-group"> 
                                    <span class="input-group-addon">Rp.</span>
                                    <input type="text" name="harga" required="required" class="form-control">
                                    <span class="input-group-addon">/Kg</span>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="hidden" name="id_user" required="required" value="<?php echo $d['id_user']; ?>" class="form-control">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <br>
                                <input type="submit" class="btn btn-primary" name="Submit" value="Simpan" />
                                <input type="reset" class="btn btn-primary" name="Submit2" value="Reset" />
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
            </div>
        </div>
    </div>
</section>