<?php
include'../koneksi.php';
if (isset($_GET)) {
    $id = $_GET['id'];
    if (empty($id)) {
        echo "Data yang dihapus belum dipilih";
    } else {
        $sql_hapus="DELETE FROM umur WHERE id_umur='$id'";
        $del = mysql_query($sql_hapus) or die ("Gagal perintah hapus".mysql_error());  
        if ($del) {
            echo "<script>alert ('data telah di Hapus ');document.location='../index.php?mod=pakan&pg=option_pakan' </script> ";    exit;
        }
    }
}

?>